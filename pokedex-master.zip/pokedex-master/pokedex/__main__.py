import sys

import pokedex.main

pokedex.main.main(*sys.argv)
